var mocha = require('mocha'),
    expect = require('chai').expect;
var first = require('../app/models/hello');
var test1 = require('../app/controllers/controllerUser');
var reqp = require('../app/controllers/route');
var assert = require('assert');
var request = require('request');
var http = require('http');
var chai = require('chai'),
    chaiHttp = require('chai-http');
chai.use(chaiHttp);
var should = chai.should();
chai.use(chaiHttp);
/*
describe('test suite', function () {
  it('should test', function () {
    expect(true).to.be.true;
  });
});
*/
/*

describe('server', function () {
  before(function () {
    http.listen(3000);
  });

  after(function () {
    http.close();
  });
});

describe('First', function () {
  it('it should return hello word', function () {
    assert.equal(first(),'hello world');
  });
});




describe('/', function () {
  it('should return 200', function (done) {
    http.get('http://localhost:3000/retreive', function (res) {
      assert.equal(200, res.statusCode);
      done();
    });
  });


});

/
it('fails, as expected', function(done) { // <= Pass in done callback
  chai.request('http://localhost:3000')
  .get('/retreive')
  .end(function(err, res) {
    expect(res).to.have.status(200);
    done();                               // <= Call done to signal callback end
  });
}) ;


var app = 'http://localhost:3000';





var should = require('should');
//var app = require('../../app');
var request = require('supertest');


*/
//Body parser

var chai = require('chai'), chaiHttp = require('chai-http');
chai.use(chaiHttp);
var app = 'http://localhost:3000';
var supertest = require('supertest');
 var api=supertest( 'http://localhost:3000'  );
//////////////




var express = require('express');
//var app = express();
var chai = require('chai');
var expect = require('chai').expect;
var should = require('should');
var supertest = require('supertest');
var server = supertest.agent("https://localhost:3000");
var request = require('supertest');
var bodyParser = require('body-parser');



it("should add report", function(done){
   var data = {
          name: 'Mr.marco', 
            surname: 'Mr.marco',
            address:'Mr.marco'
      };
        
request(app) // change here
.post('/create')
.type('json')
.expect("Content-type",/json/)
.send(data)
.expect(200)
.end(function(err,res){
  
  done();
});
});



/*

var express = require('express');
//var app = express();
var chai = require('chai');
var expect = require('chai').expect;
var should = require('should');
var supertest = require('supertest');
var server = supertest.agent("https://localhost:3000");
var request = require('supertest');
var bodyParser = require('body-parser');



it("should add report", function(done){
   var data = {
          name: 'mr', 
            surname: 'fr',
            address:'fertwee'
      };
        
request(app) // change here
.post('/update')
.type('json')
.expect("Content-type",/json/)
.send(data)
.expect(200)
.end(function(err,res){
  
  done();
});
});
*/
/*
it('Should accept the correct email and password',function(done){
      api.put("mil")
      var data = {
          name: 'john', 
            surname: 'fr',
            address:'sd'
      };
      request(app).post('/update').send(data).expect(200).end(done);       
   });

*/


/*

describe('/', function () {
  it('should return 200', function (done) {
    http.get('http://localhost:3000/delete', function (res) {
      assert.equal(200, res.statusCode);
      done();
    });
  });


});

*/

/*


describe("Inner Suite 1", function() {


    before(function() {
        console.log("ertis");
        describe('server', function() {
            before(function() {
                http.listen(3000);
            });

            after(function() {
                http.close();
            });
        });


    });

    after(function() {
        console.log("ertis2");


    });

    beforeEach(function() {
        console.log("ertis3");

        it("should add report", function(done) {
            var data = {
                name: 'marco',
                surname: 'marco',
                address: 'marco'
            };
            // request(app).post('/create').send(data).expect(200).end(done);       
            request(app) // change here
                .post('/create')
                .type('json')
                .expect("Content-type", /json/)
                .send(data)
                .expect(200)
                .end(function(err, res) {
                    //console.log("fanis to res1 eini"+res.name);
                    done();
                });
        });

    });

    afterEach(function() {
        console.log("ertis4");
        it('fails, as expected', function(done) { // <= Pass in done callback
            chai.request('http://localhost:3000')
                .get('/retreive')
                .end(function(err, res) {
                    expect(res).to.have.status(200);
                    done(); // <= Call done to signal callback end
                });
        });

      

    });

    it("Test-1", function() {
        console.log("ertis5");
        describe('/', function() {
            it('should return 200', function(done) {
                http.get('http://localhost:3000/retreive', function(res) {
                    assert.equal(200, res.statusCode);
                    done();
                });
            });


        });

        

    });

    it("Test-2", function() {
        console.log("ertis6");

      

    });

    it("Test-3", function() {

      

    });

});

*/