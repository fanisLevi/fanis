const express = require('express')
const app = express()

app.get('/create', function(req, res) {
    res.send('create route ok!')
})


app.get('/retrieve', function(req, res) {
    res.send('retrieve route ok!')
})


app.get('/update', function(req, res) {
    res.send('update route ok!')
})


app.get('/delete', function(req, res) {
    res.send('delete route ok!')
})




app.listen(3000, function() {
    console.log('Example app listening on port 3000!')
})