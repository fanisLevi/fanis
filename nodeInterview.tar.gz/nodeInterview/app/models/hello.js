var MongoClient = require('mongodb').MongoClient

module.exports=function(){
   return "hello world";
}