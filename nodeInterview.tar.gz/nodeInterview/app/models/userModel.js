var mongoose = require('mongoose');
var Schema = mongoose.Schema;
mongoose.Promise = require('bluebird');
var user = new Schema({
    name: [String],
    surname: [String],
    address: [String]

});
module.exports = mongoose.model('users', user);