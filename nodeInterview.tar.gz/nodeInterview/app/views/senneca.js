'use strict'
var Seneca = require('seneca')
var Express = require('express')
var Web = require('seneca-web')

var Routes = [{
    prefix: '/api',
    pin: 'role:api,cmd:*',
    map: {
        retreive: {
            GET: true
        },
        create: {
            GET: false,
            POST: true
        },
        update: {
            GET: false,
            PUT: true
        },
        delete: {
            GET: false,
            DELETE: true
        },
        home: {
            GET: true
        }
    }
}]
var seneca = Seneca()
var Entity = require('seneca-entity')
var MongoStore = require('mongo-store')
seneca.use(Entity);
seneca.use(MongoStore, {
    uri: 'mongodb://localhost:27017/mydatabase'
})

var config = {
    routes: Routes,
    adapter: require('seneca-web-adapter-express'),
    options: {
        parseBody: true
    },
    context: Express()
}

seneca.client()
    .use(Web, config)
    .ready(() => {
        var server = seneca.export('web/context')()
        server.listen('3000', () => {
            console.log('server started on: 3000')
        })
    })

seneca.add({
    role: 'api',
    cmd: 'home'
}, function(args, done) {
    done(null, {
        response: "hey"
    });
});

seneca.add({
    role: 'api',
    cmd: 'retreive'
}, function(args, done) {
    var users = this.make('users');
    users.list$({}, done);
});



seneca.add({
    role: 'api',
    cmd: 'create'
}, function(args, done) {

    var user = this.make('users');
    user.username = "fanis"; // 
    user.surname = "levi"; // 
    user.address = "mires"; //


    user.save$(function(err, user) {
        done(err, user.data$(false));

    });
});




seneca.add({
    role: 'api',
    cmd: 'delete'
}, function(args, done) {

    var user = this.make('users');
    user.remove$(args.id, function(err) {
        done(err, null);
    });




});


seneca.add({
    role: 'api',
    cmd: 'update'
}, function(args, done) {
    seneca.act({
            role: 'api',
            cmd: 'retreive',
            criteria: 'byId',
            id: args.id
        },
        function(err, result) {
            result.data$({
                name: args.userName,
                password: args.password,
                address: args.address,
                email: args.email
            });
            result.save$(function(err, user) {
                done(user.data$(false));
            });
        });
});