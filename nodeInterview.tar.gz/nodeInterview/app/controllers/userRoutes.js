
var express = require('express')
  , router = express.Router()

'use strict';
var db = require('../db')
var controller = require('../../app/controllers/controllerUser');

var UserInfos = require('../models/userModel.js');
router.get('/helloworld', function(req, res, next) {
    res.send(controller.sayHello());    
});


router.get('/retreive', function(req, res) {
  var collection = db.get().collection('user1')
  collection.find({}).toArray(function(err, docs) {
      console.log(docs[0])
      res.setHeader('Content-Type', 'application/json'); 
      res.send(JSON.stringify(docs[0]));
    
    })
})


router.post('/create', controller.setUsers); //return users

router.put('/update', controller.updateUsers); //return users

router.delete('/delete', controller.deleteUsers); //return users

module.exports = router
