'use strict';
var UserInfos = require('../models/userModel.js');
//mongoose.Promise = require('bluebird');
var assert = require('assert');
var MongoClient = require('mongodb').MongoClient
var URL = 'mongodb://localhost:27017/mydatabase'
module.exports.setUsers = function(req, res) { //Creates new meetup
    console.log(req.body);

    MongoClient.connect(URL, function(err, db) {
        var collection = db.collection('user1')
        collection.insert({
            name: req.body.name,
            surname: req.body.surname,
            address: req.body.address
        }, function(err, result) {})
    })

    res.send("okSet");

};


module.exports.sayHello = () => {

    return "Hello World!!!!";

};

module.exports.updateUsers = function(req, res) {

    MongoClient.connect(URL, function(err, db) {
        if (err) throw err;
        var myquery = {
            name: "john"
        };
        var newvalues = {
            name: req.body.name,
            surname: req.body.surname,
            address: req.body.address
        };
        db.collection('user1').updateOne(myquery, newvalues, function(err, res) {
            if (err) throw err;
            console.log("1 record updated");
            //db.close();
        });
    });
    res.send("okUpdate");

};



module.exports.deleteUsers = function(req, res) {
    console.log("called ths function");

    MongoClient.connect(URL, function(err, db) {
        if (err) throw err;
        var myquery = {
            name: 'sofoklis'
        };
        db.collection("user1").deleteOne(myquery, function(err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            //db.close();
        });
    });
    res.send("okDelete");
}